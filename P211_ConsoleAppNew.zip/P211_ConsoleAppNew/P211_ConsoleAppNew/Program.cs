﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonClassLibrary;

namespace P211_ConsoleAppNew
{
    public enum Seasons { Spring, Summer, Autumn, Winter }
    public enum Aylar
    {
        Yanvar = 1,
        Fevral,
        Mart,
        Aprel,
        May,
        İyun,
        İyul,
        Avqust
    }

    public enum StatusCodes
    {
        Success = 200,
        Created = 202,
        NotFound = 404,
        InternalError = 500
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine((int)Seasons.Spring);

            Person person = new Person();
            person.FavouriteSeason = Seasons.Spring;
            person.SevimliAy = Aylar.May;

            Console.ForegroundColor = ConsoleColor.Magenta;

            int statusCode = (int)StatusCodes.InternalError;

            Console.WriteLine(statusCode);
        }

        //static string ConcatWords(params string[] words)
        //{
        //    StringBuilder stringBuilder = new StringBuilder();

        //    foreach (var word in words)
        //    {
        //        stringBuilder.Append(word + " ");
        //    }

        //    return stringBuilder.ToString();
        //}
    }

    class Person
    {
        public Seasons FavouriteSeason { get; set; }
        public Aylar SevimliAy { get; set; }

    }
}
